$(document).ready(function() {

var clear_url = window.location.protocol + "//" + window.location.hostname + "/";   

//-----
    function ui_sort($obj){
        
          //вытащим какой объект(class) нужно выбрать
          var class_need = $($obj).attr("for_class");          
          
          $($obj).sortable({
            cursor: 'move',
            start: function(event, ui) {           
               /*
               var thisLi = ui.item;
               thisLi.addClass('sortNow');*/
            },                    
            stop: function(event, ui) {
              /*
              var thisLi = ui.item;
              thisLi.removeClass('sortNow'); */          
            },
            update: function(event, ui) {
            
             
              var   href         = clear_url+"options/sort/"+class_need,
                    data_of_sort = $(this).sortable("serialize");
                    
                    //alert(href);
              
                
              $.post(href, data_of_sort,  function(e){   
                    
                    var res = JSON.parse(e);            
                    if(!Boolean(res.response)){ alert(res.error_desc); }
                                        
              });
              
                
             } //end of update
            
        
          }).disableSelection();    
        
    }

//----


//Сортируем категории
    ui_sort($(".sort_cont"));

	

}); //Конец Ready