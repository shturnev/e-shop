
		<? if ($res_items): ?>
			<ul class="itemsCont sort_cont" for_class="<? echo get_class($BANNER) ?>">
				<? foreach ($res_items["items"] as $item):

					if($res_item && $res_item["ID"] == $item["ID"]){$act = "active";}else{$act = null;}
					?>
					<li class="<? echo $act; ?>" id="nomer_<? echo $item["ID"]; ?>">
						<div class="photo" style="background-image: url(<? echo $item[ph_url]."small/".$item["photo"]; ?>)"></div>
						<a class="edit" href="<? echo $this_page."?ID=".$item["ID"]; ?>"></a>
						<a class="delete" href="<? echo $PATH->clear_url()."face/options.php?delBanner=".$item["ID"]; ?>"></a>
					</li>
				<? endforeach; ?>
			</ul>
		<? endif; ?>
